
function acessorios() {
    window.location.href = "acessorios.php";
}

function cadastrar() {
    window.location.href = "cadastro.php";
}

function carrinho() {
    alert("Ainda não implementado.");

}

function confirmarCadastro() {
    alert("Cadastro efetuado com sucesso!!");
    window.location.href = "conta.php";
}

function confirmarCompra() {
    alert("Compra efetuada com sucesso!!");
}

function conjuntos() {
    alert("Ainda não implementado.");
}

function conta() {
    window.location.href = "conta.php";
}



function esqueceusenha() {
    alert("Ainda não implementado.");
}

/*function home() {
    window.location.href = "paginaprincipal.php";
}*/
function paginaprincipal() {
    window.location.href = "paginaprincipal.php";
}

function perucas() {
    window.location.href = "peruca.php";
}

function sapatos() {
    alert("Ainda não implementado.");
}

function roupas() {
    alert("Ainda não implementado.");
}
function lentes() {
    alert("Ainda não implementado.");
}

function mostrarEsconder(){
    var senha = document.getElementById("senha");
    var olho = document.getElementById("olho");

    if(senha.type == "password"){
        senha.type = "text";
        olho.src = "public/images/olho.svg";
    } 
    
    else {
        senha.type = "password";
        olho.src = "public/images/olhofechado.svg";
    }

}