<?php 

namespace App\Controller;

use App\Model\P\Produto;

use PDOException;

/**
* Esta classe estende a classe abstrata Controller
* e
* é responsável por chamar a view correta para os tratamentos de login/
* informações/cadastro de usuários
* passando os dados fornecidos pelo usuário. 
*/
class produtoController extends Controller  {
    
    /**
    * 
    * @var Produto O usuário que será chamado (ou cadastrado)
    */
    private $loggedUser;
    
    /**
    *  Este método cria uma sessão
    * a qual irá armazenar o(s) usuário(s).
    */
    function __construct() {
       /* session_start();*/
        if (isset($_SESSION['produto'])) $this->loggedUser = $_SESSION['produto'];
    }
    

    
    
    public function acessories()
    {
        $produtos = Produto::buscarCategoria("Acessórios");
        $this->view('acessorios',$produtos);
    }
    public function peruquitas()
    {   $produtos = Produto::buscarCategoria("Peruca");
        $this->view('peruca',$produtos);
    }
    
       
    
    public function descricao()

    {  $nome = $_GET['peruca'];
        $produto = Produto::buscarProduto($nome);
        if($produto){
            $this->view('descricao',$produto);
        }else{
            header('Location: ' . BASEPATH . 'wigs');
        }
        
        
        
     
        
        
    }
   


    public function rec()
    {
        $produtos = Produto::buscarProdutos();
        shuffle($produtos);
        
        $this->view('recomendado', $produtos);
    }

    
    
}


    ?>