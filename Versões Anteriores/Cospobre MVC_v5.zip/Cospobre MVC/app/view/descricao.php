<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Descrição</title>
    <link rel="shortcut icon" type="imagex/png" href="<?= BASEPATH ?>public/images/cabecaum.ico" />
    <link rel="stylesheet" href="<?= BASEPATH ?>public/style/descricao.css" />
    <script src="<?= BASEPATH ?>public/script/script.js"></script>
    <script src="<?= BASEPATH ?>public/script/menu.js"></script>
</head>

<body>
  <header>
    <div class="container">
      <a href="<?= BASEPATH ?>home" >
        <img class="logo" src="<?= BASEPATH ?>public/images/logo.svg" alt="logo" />
      </a>
      <div class="menu-section">
        <div class="menu-toggle">
          <div class="one"></div>
          <div class="two"></div>
          <div class="three"></div>
        </div>
        <nav>
          <ul>
            <li class="search">
              <input
                type="text"
                placeholder="Buscar produtos, nome, categoria, ..."
              />
            </li>
            <li>
            <a href="<?= BASEPATH ?>login" class="right-content">
                  <ion-icon
                    name="person-outline"
                    class="conta"
                    
                  ></ion-icon>
                  <span id="icone" >Conta</span>
                </a>
              </li>
              <li> 
                <a href="<?= BASEPATH ?>logout" class="right-content"> 
                <ion-icon 
                name="log-out" 
                class="sair"
                href="<?= BASEPATH ?>logout">
                </ion-icon>
                <span id="icone" href="<?= BASEPATH ?>logout" >Sair</span>
                </a> 
              </li>
              <li>
                <a href="<?= BASEPATH ?>chart"  class="right-content">
                  <ion-icon
                    name="cart-outline"
                    class="carrinho"
                  ></ion-icon> <!-- implementar a tela carrinho e php -->
                  <span id="icone">Carrinho</span>
                </a>
              </li>
            </ul>
          </nav>
        </div>
      </div>
    
    </header>

  <div class="teste">
    <div class="teste-top">
      <div class="left">
      <?php if (is_null($data)) {           
          
                  } else{ ?>
        <img src="<?= $data->img ?>" alt="peruca--main">
        <div class="vertical">
          <img src="<?= $data->img ?>" alt="peruca-saber-1">
          <img src="<?= $data->img ?>" alt="peruca-saber-2">
          <img src="<?= $data->img ?>" alt="peruca-saber-3">
        </div>
      </div>
      <div class="right">
        <p class="product-name"><?= $data->nome ?></p>
        <?php } ?>
        
        <div class="side-by-side">
          <img class="good" src="<?= BASEPATH ?>public/images/good.svg">
          <p>(132)</p>
        </div>
        <h1><?= $data->preco ?></h1>
        <hr>
        <div class="side-by-side">
          <div class="aaa">
            <button class="seleciona">Selecione o tamanho</button>
            <button class="adiciona">Adicionar o carrinho</button>
          </div>

          <div class="aaa">
            <h4>AVALIAR</h4>
            <img id="thumb" src="<?= BASEPATH ?>public/images/good.svg">
            <img id="thumb" src="<?= BASEPATH ?>public/images/meee.svg">
          </div>
        </div>
      </div>
    </div>

    <div class="teste-bottom">
      <div class="bottom">
        <h3>Descrição</h3>
          <p><strong>Material:</strong> Fibras sintéticas de alta qualidade.</p>
          <p><strong>Cor:</strong> como mostra na imagem.</p>
          <p><strong>Comprimento:</strong> - 10cm / Corte lateral: 27cm</p></br>
          Essa peruca é entregue na forma em que esta na imagem, contudo pode ser necessário fazer ajustes de acordo com o rosto.
      </div>
    </div>    
  </div>

  <?php include 'app/view/recomendado.php' ?>

  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
  <script src="script.js"></script>
  <script src="menu.js"></script>
</body>

</html>