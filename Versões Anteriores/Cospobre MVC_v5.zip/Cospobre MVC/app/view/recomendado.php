
<?php use App\Model\P\Produto;?>
<div class="recomendados">
    <h3>Recomendados</h3>
    <?php $prod = Produto::buscarCategoria("Peruca");
          shuffle($prod); ?>

<?php for ($i = 0; $i < 3; $i++) { ?>
    <div class="card">
    <form action ="<?= BASEPATH ?>description" method = 'GET' class = "form_desc">
            <input type= "hidden" name = "peruca" value = "<?= $prod[$i]->nome ?>" >   
            <button type = "submit" >
            <img id="cartas" src="<?= $prod[$i]->img ?>" />
    </button>
    </form>
      <div class="card-content">
        <h4><?= $prod[$i]->nome ?></h4>
      </div>
      <div class="card-price">
        <p class="price"><?= $prod[$i]->preco ?></p>
      </div>
    </div>
    <?php } ?>
     


  </div>